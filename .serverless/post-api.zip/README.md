sls deploy 

